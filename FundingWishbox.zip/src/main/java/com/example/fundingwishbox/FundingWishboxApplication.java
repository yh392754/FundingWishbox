package com.example.fundingwishbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundingWishboxApplication {

    public static void main(String[] args) {
        SpringApplication.run(FundingWishboxApplication.class, args);
    }

}
